using System.Diagnostics;
using System.Security.Cryptography;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header( "Movement parameters")]
    [Range(0.01f, 20.0f)][SerializeField] private float moveSpeed = 0.1f;
    [Range(0.01f, 20.0f)][SerializeField] private float jumpForce = 6.0f;
    [Space(10)]
    private Rigidbody2D rigidBody;
    private Animator animator;
    private bool isrunning = false;
    private bool isfacingright = true;
    [SerializeField] private LayerMask groundLayer;
    const float rayLength = 0.2f;
    Vector2 startPosition;
    

    void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        startPosition = transform.position;
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    bool IsGrounded()
    {
        return Physics2D.Raycast(this.transform.position, Vector2.down, rayLength, groundLayer.value);
    }

    void Jump()
    {

        if( IsGrounded()   )
        { 
            rigidBody.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            UnityEngine.Debug.Log("jumping");
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance == null) return;
        if (GameManager.instance.currentGameState == GameState.GAME)
        {
            isrunning = false;
            if (Input.GetKey(KeyCode.RightArrow))
            {
                transform.Translate(moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isrunning = true;
                if (isfacingright == false)
                {
                    Flip();
                }
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.Translate(-moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isrunning = true;
                if (isfacingright)
                {
                    Flip();
                }
            }
            if (Input.GetMouseButtonDown(0))
            { Jump(); }
            UnityEngine.Debug.DrawRay(transform.position, rayLength * Vector3.down, Color.white, 0.2f, false);
            animator.SetBool("IsGrounded", IsGrounded());
            animator.SetBool("IsRunning", isrunning);
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("LevelExit"))
        {
            if (GameManager.instance.keysCompleted)
            {
                GameManager.instance.AddPoints(100*GameManager.instance.lives);
                GameManager.instance.LevelCompleted();
                UnityEngine.Debug.Log("You Won");
            }
            else
            {
                UnityEngine.Debug.Log("You need all the keys");
            }
        }
        else
        if (col.CompareTag("LevelFall"))
        {
            UnityEngine.Debug.Log("fall over");
            GameManager.instance.AddLives(-1);
            transform.position = startPosition;
        }
        else 
        if (col.CompareTag("Bonus"))
        {
            //UnityEngine.Debug.Log("Bonus");
            GameManager.instance.AddPoints(1);
            col.gameObject.SetActive(false);
        }
        else
        if (col.CompareTag("Enemy"))
        {
            if (transform.position.y > col.gameObject.transform.position.y)
            {
                UnityEngine.Debug.Log("Killed an enemy");
                GameManager.instance.AddKills(1);
            }
            else
            {
                transform.position = startPosition;
                UnityEngine.Debug.Log("You died");
                GameManager.instance.AddLives(-1);
            }
        }
        else
        if (col.CompareTag("KR"))
        {
            GameManager.instance.AddKeys(0);
            col.gameObject.SetActive(false);
        }
        else
        if (col.CompareTag("KG"))
        {
            GameManager.instance.AddKeys(1);
            col.gameObject.SetActive(false);
        }
        else
        if (col.CompareTag("KB"))
        {
            GameManager.instance.AddKeys(2);
            col.gameObject.SetActive(false);
        }
        else
        if (col.CompareTag("Heart"))
        {
            GameManager.instance.AddLives(1);
            col.gameObject.SetActive(false);
            UnityEngine.Debug.Log("You gained 1 life");
        }

    }

    private void Flip()
    {
        isfacingright =! isfacingright;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;

    }
}
