using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;
using TMPro;



public enum GameState { GAME, PAUSE_MENU, LEVEL_COMPLETED, GAME_OVER};
public class GameManager : MonoBehaviour
{
    private int killed = 0;
    public TMP_Text killedText;
    private int seconds = 0;
    private int minutes = 0;
    private float timer = 0.0f;
    public TMP_Text timerText;
    public Canvas pauseMenuCanvas;
    public Canvas levelCompletedCanvas;
    public Image[] keysTab;
    public Canvas inGameCanvas;
    public TMP_Text livesText;
    public TMP_Text scoreText;
    private int keysFound = 0;
    public int lives = 3;
    public static int maxKeysNumber = 3;
    public bool keysCompleted = false;
    private bool hold = false;
    private int score = 0;
    public static GameManager instance;
    public GameState currentGameState = GameState.PAUSE_MENU;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //currentGameState = GameState.GAME;
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        seconds = (int)(timer) % 60;
        minutes = (int)(timer) / 60;
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        if (Input.GetKey(KeyCode.Escape) && hold == false)
        {
            hold = true;
            
            if (currentGameState == GameState.GAME)
            {
                PauseMenu();
            }
            else if (currentGameState == GameState.PAUSE_MENU)
            {
                InGame();
            }
        } else if (Input.GetKey(KeyCode.Escape) != true)
        {
            hold = false;
        }
    }

    void Awake()
    {
        InGame();

        if (instance == null)
        {
            instance = this;
        } else
        {
            UnityEngine.Debug.LogError("Duplicated Game Manager", gameObject);
        }
        scoreText.text = score.ToString();
        livesText.text = lives.ToString();
        keysTab[0].color = Color.grey;
        keysTab[1].color = Color.grey;
        keysTab[2].color = Color.grey;
    }

    void SetGameState (GameState newGameState)
    {
        currentGameState = newGameState;
        if (currentGameState == GameState.GAME)
        {
            inGameCanvas.enabled = true;
        }
        else
        {
            inGameCanvas.enabled = false;
        }
        pauseMenuCanvas.enabled = currentGameState == GameState.PAUSE_MENU;
        levelCompletedCanvas.enabled = currentGameState == GameState.LEVEL_COMPLETED;
    }
    public void PauseMenu()
    {
        SetGameState (GameState.PAUSE_MENU);
    }
    public void InGame()
    {
        SetGameState(GameState.GAME);
    }
    public void LevelCompleted()
    {
        SetGameState(GameState.LEVEL_COMPLETED);
    }
    public void GameOver()
    {
        SetGameState(GameState.GAME_OVER);
    }

    public void AddPoints(int points)
    {
        score += points;
        UnityEngine.Debug.Log(score);
        scoreText.text = score.ToString();
    }

    public void AddKeys(int num)
    {
        keysFound += 1;
        //UnityEngine.Debug.Log("zebrano klucz");
        if (keysFound == maxKeysNumber) 
            {
            keysCompleted = true;
            //UnityEngine.Debug.Log("zebrano wszystkie klucze");
        }
        if(num == 0)
        {
            keysTab[0].color = Color.red;
        }
        if (num == 1)
        {
            keysTab[1].color = Color.green;
        }
        if (num == 2)
        {
            keysTab[2].color = Color.blue;
        }
    }

    public void AddLives(int livesNumber)
    {
        lives += livesNumber;
        livesText.text = lives.ToString();
    }

    public void OnResumeButtonClicked()
    {
        InGame();
    }
    public void OnRestartButtonClicked()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void OnExitButtonClicked()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void AddKills(int points)
    {
        killed += points;
        UnityEngine.Debug.Log(killed);
        killedText.text = killed.ToString();
    }

}
